from __future__ import annotations

from pathlib import Path

import pandas as pd
from pandas.api.types import is_numeric_dtype

from .config import TimeRangeConfig


class DataValidationError(ValueError):
    """Raised when an input Parquet file violates the required contract."""


def _timestamp_index(index: pd.Index, path: Path) -> pd.DatetimeIndex:
    if isinstance(index, pd.RangeIndex) or is_numeric_dtype(index.dtype):
        raise DataValidationError(f"Parquet index must contain timestamps: {path}")
    try:
        timestamp = pd.DatetimeIndex(pd.to_datetime(index, utc=True, errors="raise"), name="timestamp")
    except (TypeError, ValueError) as exc:
        raise DataValidationError(f"Parquet index must contain valid timestamps: {path}") from exc
    if timestamp.has_duplicates:
        raise DataValidationError(f"Parquet index contains duplicate timestamps: {path}")
    return timestamp


def _slice_time_range(frame: pd.DataFrame, time_range: TimeRangeConfig, path: Path) -> pd.DataFrame:
    selected = frame.loc[
        (frame.index >= time_range.start) & (frame.index < time_range.end)
    ].sort_index()
    if selected.empty:
        raise DataValidationError(
            f"No rows from {path} fall in [{time_range.start}, {time_range.end})."
        )
    return selected


def read_factor(path: Path, time_range: TimeRangeConfig) -> pd.DataFrame:
    if not path.is_file():
        raise FileNotFoundError(f"Factor parquet not found: {path}")
    frame = pd.read_parquet(path)
    if len(frame.columns) != 1:
        raise DataValidationError(
            f"Factor parquet must contain exactly one value column; found {len(frame.columns)}: {path}"
        )
    column = frame.columns[0]
    if not is_numeric_dtype(frame[column]):
        raise DataValidationError(f"Factor column must be numeric: {path}")

    frame = frame.copy()
    frame.index = _timestamp_index(frame.index, path)
    frame = frame.rename(columns={column: "factor"})[["factor"]]
    return _slice_time_range(frame, time_range, path)


def read_returns(path: Path, time_range: TimeRangeConfig) -> pd.DataFrame:
    if not path.is_file():
        raise FileNotFoundError(f"Return parquet not found: {path}")
    frame = pd.read_parquet(path)

    if "timestamp" in frame.columns:
        if "return" not in frame.columns:
            raise DataValidationError(
                f"Return parquet with a timestamp column must also contain a return column: {path}"
            )
        frame = frame[["timestamp", "return"]].set_index("timestamp")
    else:
        if len(frame.columns) != 1:
            raise DataValidationError(
                f"Indexed return parquet must contain exactly one value column: {path}"
            )
        frame = frame.rename(columns={frame.columns[0]: "return"})[["return"]]

    if not is_numeric_dtype(frame["return"]):
        raise DataValidationError(f"Return column must be numeric: {path}")
    frame.index = _timestamp_index(frame.index, path)
    return _slice_time_range(frame[["return"]], time_range, path)
