from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Sequence

from ._version import __version__
from .runner import run_backtest


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="alphalab",
        description="YAML-driven multi-horizon factor backtesting.",
    )
    parser.add_argument("--version", action="version", version=__version__)
    commands = parser.add_subparsers(dest="command", required=True)
    backtest = commands.add_parser("backtest", help="Run one factor backtest.")
    backtest.add_argument(
        "--config",
        type=Path,
        required=True,
        help="Path to the backtest YAML file.",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        result = run_backtest(args.config)
    except (OSError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    accepted = result.summary["accepted_horizons"]
    rejected = result.summary["rejected_horizons"]
    print(f"Factor: {result.summary['factor']}")
    print(f"Accepted horizons: {accepted}")
    print(f"Rejected horizons: {rejected}")
    if result.generated_return_files:
        print("Generated return files:")
        for path in result.generated_return_files:
            print(f"- {path}")
    else:
        print("Generated return files: none")
    print(f"Results: {result.output_directory}")
    if result.html_report_path is not None:
        print(f"HTML report: {result.html_report_path}")
    if result.registry_directory is not None:
        print(f"Registry: {result.registry_directory}")
    else:
        print("Registry: not admitted")
    return 0
