from __future__ import annotations

from io import BytesIO
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np

from .engine import HorizonResult


def _number(value: Any, decimals: int = 4) -> str:
    if value is None or not np.isfinite(value):
        return "nan"
    return f"{value:.{decimals}f}"


def _percent(value: Any) -> str:
    if value is None or not np.isfinite(value):
        return "nan"
    return f"{value:.2%}"


def render_report_png(
    factor_name: str,
    result: HorizonResult,
    admission: dict[str, Any],
) -> bytes:
    metrics = result.metrics
    strategy = result.strategy
    long_nav = (1 + strategy["long_return"]).cumprod()
    short_nav = (1 + strategy["short_return"]).cumprod()
    drawdown = strategy["nav"] / strategy["nav"].cummax() - 1

    figure, axes = plt.subplots(3, 2, figsize=(17, 14), constrained_layout=True)
    figure.suptitle(
        f"{factor_name} backtest - {result.horizon_minutes}min "
        f"({'PASS' if admission['passed'] else 'REJECT'})",
        fontsize=16,
    )

    summary_ax = axes[0, 0]
    summary_ax.axis("off")
    rows = [
        ["Valid samples", str(metrics["valid_samples"])],
        ["Coverage", _percent(metrics["coverage"])],
        ["IC", _number(metrics["ic"])],
        ["ICIR", _number(metrics["icir"])],
        ["Annual return", _percent(metrics["annual_return"])],
        ["Sharpe", _number(metrics["sharpe"])],
        ["Max drawdown", _percent(metrics["max_drawdown"])],
        ["Calmar", _number(metrics["calmar"])],
        ["Final NAV", _number(metrics["final_nav"])],
        ["Open frequency", _percent(metrics["open_frequency"])],
    ]
    table = summary_ax.table(
        cellText=rows,
        colLabels=["Metric", "Value"],
        cellLoc="center",
        loc="center",
    )
    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1, 1.4)
    summary_ax.set_title("Summary")

    group_ax = axes[0, 1]
    group_values = result.group_returns.to_numpy() * 10_000
    positions = np.arange(len(group_values))
    colors = ["#16a34a" if value >= 0 else "#dc2626" for value in group_values]
    group_ax.bar(positions, group_values, color=colors)
    group_ax.set_xticks(positions)
    group_ax.set_xticklabels([f"Q{group}" for group in result.group_returns.index])
    group_ax.axhline(0, color="black", linewidth=0.8)
    group_ax.set_title("Mean Forward Return by Group")
    group_ax.set_ylabel("Return (bp)")

    nav_ax = axes[1, 0]
    nav_ax.plot(strategy.index, strategy["nav"], color="#16a34a", label="Combined")
    nav_ax.set_title(f"Combined NAV | Final {_number(metrics['final_nav'], 2)}")
    nav_ax.set_ylabel("NAV")
    nav_ax.legend()

    sides_ax = axes[1, 1]
    sides_ax.plot(strategy.index, long_nav, color="#2563eb", label="Long")
    sides_ax.plot(strategy.index, short_nav, color="#f97316", label="Short")
    sides_ax.set_title("Long and Short NAV")
    sides_ax.set_ylabel("NAV")
    sides_ax.legend()

    ic_ax = axes[2, 0]
    if result.daily_ic.empty:
        ic_ax.text(0.5, 0.5, "No daily IC", ha="center", va="center")
    else:
        cumulative_ic = result.daily_ic.cumsum()
        ic_ax.plot(cumulative_ic.index, cumulative_ic.values, color="#0f766e")
        ic_ax.axhline(0, color="black", linewidth=0.8)
    ic_ax.set_title("Cumulative Daily IC")
    ic_ax.set_ylabel("IC")

    drawdown_ax = axes[2, 1]
    drawdown_ax.fill_between(
        strategy.index,
        drawdown.values,
        0,
        color="#dc2626",
        alpha=0.35,
    )
    drawdown_ax.set_title("Combined Drawdown")
    drawdown_ax.set_ylabel("Drawdown")

    for axis in axes.flat:
        if axis is summary_ax:
            continue
        axis.grid(True, alpha=0.3)
        for label in axis.get_xticklabels():
            label.set_rotation(30)
            label.set_ha("right")

    buffer = BytesIO()
    try:
        figure.savefig(buffer, format="png", dpi=150)
        return buffer.getvalue()
    finally:
        plt.close(figure)


def save_report(
    factor_name: str,
    result: HorizonResult,
    admission: dict[str, Any],
    output_path: Path,
) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_bytes(render_report_png(factor_name, result, admission))
