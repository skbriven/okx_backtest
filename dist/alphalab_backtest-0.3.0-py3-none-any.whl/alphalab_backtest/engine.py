from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from .config import BacktestConfig


SECONDS_PER_YEAR = 365 * 24 * 60 * 60


class BacktestError(ValueError):
    """Raised when aligned data cannot produce a valid backtest."""


@dataclass
class HorizonResult:
    horizon_minutes: int
    metrics: dict[str, float | int]
    group_returns: pd.Series
    daily_ic: pd.Series
    strategy: pd.DataFrame


def _add_rolling_direction(
    frame: pd.DataFrame,
    horizon_minutes: int,
    window: str,
    min_observations: int,
) -> pd.DataFrame:
    current = frame.sort_index().copy()
    known = current[["factor", "return"]].copy()
    known.index = known.index + pd.Timedelta(minutes=horizon_minutes)
    known.index.name = "known_time"
    history_ic = (
        known["factor"]
        .rolling(window, min_periods=min_observations)
        .corr(known["return"])
        .rename("history_ic")
        .reset_index()
    )

    directed = pd.merge_asof(
        current.reset_index().sort_values("timestamp"),
        history_ic.sort_values("known_time"),
        left_on="timestamp",
        right_on="known_time",
        direction="backward",
    ).set_index("timestamp")
    directed.index.name = "timestamp"
    directed["factor_direction"] = np.where(directed["history_ic"] < 0, -1, 1)
    directed["signal_factor"] = directed["factor"] * directed["factor_direction"]
    return directed


def _add_rolling_groups(
    frame: pd.DataFrame,
    window: str,
    min_observations: int,
    quantiles: int,
) -> pd.DataFrame:
    grouped = frame.sort_index().copy()
    history_factor = grouped["factor"].shift(1)
    threshold_columns: list[str] = []
    for group in range(1, quantiles):
        column = f"q{group}"
        threshold_columns.append(column)
        grouped[column] = history_factor.rolling(
            window,
            min_periods=min_observations,
        ).quantile(group / quantiles)

    thresholds = grouped[threshold_columns].to_numpy()
    has_thresholds = ~np.isnan(thresholds).any(axis=1)
    raw_groups = 1 + (grouped["factor"].to_numpy()[:, None] > thresholds).sum(axis=1)
    groups = raw_groups.astype(float)
    groups[~has_thresholds] = np.nan
    groups = np.where(
        grouped["factor_direction"].to_numpy() == -1,
        quantiles + 1 - groups,
        groups,
    )
    grouped["group"] = groups
    return grouped.drop(columns=threshold_columns)


def _calc_ic(frame: pd.DataFrame) -> tuple[float, pd.Series, float]:
    ic = frame["signal_factor"].corr(frame["return"])

    def daily_corr(day: pd.DataFrame) -> float:
        valid = day[["signal_factor", "return"]].dropna()
        if (
            len(valid) < 2
            or valid["signal_factor"].nunique() < 2
            or valid["return"].nunique() < 2
        ):
            return np.nan
        return valid["signal_factor"].corr(valid["return"])

    daily_ic = (
        frame.groupby(pd.Grouper(freq="1D"))[["signal_factor", "return"]]
        .apply(daily_corr)
        .dropna()
    )
    daily_std = daily_ic.std(ddof=1)
    if len(daily_ic) < 2 or daily_std == 0 or np.isnan(daily_std):
        icir = np.nan
    else:
        icir = daily_ic.mean() / daily_std * np.sqrt(365)
    return float(ic), daily_ic, float(icir)


def _select_rebalance_rows(frame: pd.DataFrame, horizon_minutes: int) -> pd.DataFrame:
    interval_ns = pd.Timedelta(minutes=horizon_minutes).value
    mask = frame.index.asi8 % interval_ns == 0
    return frame.loc[mask].copy()


def _turnover(position: pd.Series) -> pd.Series:
    turnover = position.diff().abs()
    if not turnover.empty:
        turnover.iloc[0] = abs(position.iloc[0])
    return turnover


def _calc_nav(returns: pd.Series) -> pd.Series:
    return (1 + returns.fillna(0)).cumprod()


def _calc_performance(returns: pd.Series) -> dict[str, float]:
    returns = returns.dropna()
    if returns.empty:
        return {
            "annual_return": np.nan,
            "sharpe": np.nan,
            "max_drawdown": np.nan,
            "calmar": np.nan,
            "final_nav": np.nan,
        }

    nav = _calc_nav(returns)
    elapsed_seconds = (returns.index[-1] - returns.index[0]).total_seconds()
    years = elapsed_seconds / SECONDS_PER_YEAR
    if years <= 0 or nav.iloc[-1] <= 0:
        annual_return = np.nan
        observations_per_year = np.nan
    else:
        annual_return = nav.iloc[-1] ** (1 / years) - 1
        observations_per_year = len(returns) / years

    standard_deviation = returns.std(ddof=1)
    if (
        standard_deviation == 0
        or np.isnan(standard_deviation)
        or np.isnan(observations_per_year)
    ):
        sharpe = np.nan
    else:
        sharpe = returns.mean() / standard_deviation * np.sqrt(observations_per_year)

    drawdown = nav / nav.cummax() - 1
    max_drawdown = drawdown.min()
    if max_drawdown < 0 and not np.isnan(annual_return):
        calmar = annual_return / abs(max_drawdown)
    else:
        calmar = np.nan

    return {
        "annual_return": float(annual_return),
        "sharpe": float(sharpe),
        "max_drawdown": float(max_drawdown),
        "calmar": float(calmar),
        "final_nav": float(nav.iloc[-1]),
    }


def _add_strategy_returns(frame: pd.DataFrame, config: BacktestConfig) -> pd.DataFrame:
    strategy = frame.sort_index().copy()
    long_mask = strategy["group"].isin(config.grouping.long_groups)
    short_mask = strategy["group"].isin(config.grouping.short_groups)
    strategy["long_position"] = long_mask.astype(float)
    strategy["short_position"] = -short_mask.astype(float)
    strategy["position"] = strategy["long_position"] + strategy["short_position"]

    cost_rate = config.costs.total_rate
    strategy["long_turnover"] = _turnover(strategy["long_position"])
    strategy["short_turnover"] = _turnover(strategy["short_position"])
    strategy["turnover"] = _turnover(strategy["position"])
    strategy["long_return"] = (
        strategy["long_position"] * strategy["return"]
        - strategy["long_turnover"] * cost_rate
    )
    strategy["short_return"] = (
        strategy["short_position"] * strategy["return"]
        - strategy["short_turnover"] * cost_rate
    )
    strategy["gross_return"] = strategy["position"] * strategy["return"]
    strategy["cost"] = strategy["turnover"] * cost_rate
    strategy["net_return"] = strategy["gross_return"] - strategy["cost"]
    strategy["nav"] = _calc_nav(strategy["net_return"])
    return strategy


def run_horizon(
    factor: pd.DataFrame,
    returns: pd.DataFrame,
    horizon_minutes: int,
    config: BacktestConfig,
) -> HorizonResult:
    aligned = factor.join(returns, how="inner")
    valid = aligned.dropna(subset=["factor", "return"]).copy()
    if len(valid) < config.direction.min_observations:
        raise BacktestError(
            f"{horizon_minutes}min requires at least "
            f"{config.direction.min_observations} aligned non-null rows; found {len(valid)}."
        )

    directed = _add_rolling_direction(
        valid,
        horizon_minutes,
        config.direction.window,
        config.direction.min_observations,
    )
    grouped = _add_rolling_groups(
        directed,
        config.direction.window,
        config.direction.min_observations,
        config.grouping.quantiles,
    ).dropna(subset=["history_ic", "signal_factor", "group"])
    if grouped.empty:
        raise BacktestError(
            f"{horizon_minutes}min has no rows after the rolling-history warm-up."
        )
    grouped["group"] = grouped["group"].astype(int)

    ic, daily_ic, icir = _calc_ic(grouped)
    group_returns = (
        grouped.groupby("group")["return"]
        .mean()
        .reindex(range(1, config.grouping.quantiles + 1))
    )

    rebalance = _select_rebalance_rows(grouped, horizon_minutes)
    if rebalance.empty:
        raise BacktestError(f"{horizon_minutes}min has no matching rebalance timestamps.")
    strategy = _add_strategy_returns(rebalance, config)

    long_metrics = _calc_performance(strategy["long_return"])
    short_metrics = _calc_performance(strategy["short_return"])
    combined_metrics = _calc_performance(strategy["net_return"])
    long_count = int((strategy["long_position"] == 1).sum())
    short_count = int((strategy["short_position"] == -1).sum())
    open_count = long_count + short_count
    coverage = len(valid) / len(factor) if len(factor) else np.nan

    metrics: dict[str, float | int] = {
        "horizon_minutes": horizon_minutes,
        "factor_samples": len(factor),
        "aligned_non_null_samples": len(valid),
        "valid_samples": len(grouped),
        "trade_samples": len(strategy),
        "coverage": float(coverage),
        "ic": ic,
        "icir": icir,
        "long_count": long_count,
        "short_count": short_count,
        "open_count": open_count,
        "open_frequency": open_count / len(strategy),
        "annual_return": combined_metrics["annual_return"],
        "sharpe": combined_metrics["sharpe"],
        "max_drawdown": combined_metrics["max_drawdown"],
        "calmar": combined_metrics["calmar"],
        "final_nav": combined_metrics["final_nav"],
        "long_annual_return": long_metrics["annual_return"],
        "long_sharpe": long_metrics["sharpe"],
        "long_max_drawdown": long_metrics["max_drawdown"],
        "long_final_nav": long_metrics["final_nav"],
        "short_annual_return": short_metrics["annual_return"],
        "short_sharpe": short_metrics["sharpe"],
        "short_max_drawdown": short_metrics["max_drawdown"],
        "short_final_nav": short_metrics["final_nav"],
    }
    return HorizonResult(
        horizon_minutes=horizon_minutes,
        metrics=metrics,
        group_returns=group_returns,
        daily_ic=daily_ic,
        strategy=strategy,
    )
