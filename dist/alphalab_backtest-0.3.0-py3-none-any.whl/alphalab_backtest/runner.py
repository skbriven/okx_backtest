from __future__ import annotations

import hashlib
import json
import math
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from ._version import __version__
from .admission import evaluate_admission
from .config import Config, load_config
from .data import read_factor, read_returns
from .engine import HorizonResult, run_horizon
from .future_returns import read_close, write_future_returns
from .html_report import save_html_report
from .report import render_report_png


@dataclass(frozen=True)
class BacktestRunResult:
    summary: dict[str, Any]
    output_directory: Path
    registry_directory: Path | None
    generated_return_files: tuple[Path, ...]
    html_report_path: Path | None


def _json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.generic):
        value = value.item()
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as file:
        json.dump(_json_safe(payload), file, ensure_ascii=False, indent=2)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as file:
        for block in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _horizon_payload(
    factor_name: str,
    result: HorizonResult,
    admission: dict[str, Any],
    config: Config,
    return_path: Path,
    return_file_generated: bool,
) -> dict[str, Any]:
    return {
        "factor": factor_name,
        "instrument": config.market.instrument,
        "horizon_minutes": result.horizon_minutes,
        "return_path": str(return_path),
        "return_file_generated": return_file_generated,
        "time_range": {
            "start": config.time_range.start.isoformat(),
            "end": config.time_range.end.isoformat(),
            "interval": "[start, end)",
        },
        "metrics": result.metrics,
        "group_mean_forward_returns": {
            f"Q{int(group)}": value
            for group, value in result.group_returns.items()
        },
        "admission": admission,
    }


def _save_strategy(path: Path, result: HorizonResult) -> None:
    strategy = result.strategy.reset_index().rename(columns={"return": "forward_return"})
    columns = [
        "timestamp",
        "factor",
        "signal_factor",
        "history_ic",
        "factor_direction",
        "group",
        "forward_return",
        "long_position",
        "short_position",
        "position",
        "turnover",
        "gross_return",
        "cost",
        "net_return",
        "nav",
    ]
    strategy[columns].to_parquet(path, index=False)


def _write_registry(
    config: Config,
    summary: dict[str, Any],
    horizon_payloads: dict[int, dict[str, Any]],
) -> Path:
    target = (
        config.registry.directory
        / config.market.instrument
        / config.factor.name
    )
    if target.exists():
        if not config.registry.overwrite:
            raise FileExistsError(
                f"Factor registry entry already exists: {target}. "
                "Set registry.overwrite to true to replace it."
            )
        shutil.rmtree(target)

    target.mkdir(parents=True)
    if config.registry.copy_factor_file:
        shutil.copy2(config.factor.path, target / "factor.parquet")
    shutil.copy2(config.source_path, target / "config.snapshot.yaml")

    accepted_horizons = summary["accepted_horizons"]
    metadata = {
        "library_version": __version__,
        "factor": config.factor.name,
        "instrument": config.market.instrument,
        "factor_source": str(config.factor.path),
        "factor_sha256": _sha256(config.factor.path),
        "swap_source": str(config.market.close_path),
        "factor_copied": config.registry.copy_factor_file,
        "time_range": summary["time_range"],
        "accepted_horizons": accepted_horizons,
        "rejected_horizons": summary["rejected_horizons"],
    }
    _write_json(target / "metadata.json", metadata)

    for horizon in accepted_horizons:
        _write_json(
            target / "horizons" / f"{horizon}min" / "metrics.json",
            horizon_payloads[horizon],
        )
    return target


def run_backtest(config_or_path: Config | str | Path) -> BacktestRunResult:
    config = (
        config_or_path
        if isinstance(config_or_path, Config)
        else load_config(config_or_path)
    )

    factor = read_factor(config.factor.path, config.time_range)
    return_paths = {
        horizon: config.returns.path_for(config.market.instrument, horizon)
        for horizon in config.backtest.prediction_horizons
    }
    missing_horizons = [
        horizon
        for horizon, path in return_paths.items()
        if not path.is_file()
    ]
    generated_return_files: list[Path] = []
    if missing_horizons:
        close = read_close(config.market.close_path)
        for horizon in missing_horizons:
            generated_return_files.append(
                write_future_returns(close, horizon, return_paths[horizon])
            )

    output_root = (
        config.output.directory
        / config.market.instrument
        / config.factor.name
    )
    output_root.mkdir(parents=True, exist_ok=True)
    if config.output.save_config_snapshot:
        shutil.copy2(config.source_path, output_root / "config.snapshot.yaml")

    horizon_payloads: dict[int, dict[str, Any]] = {}
    report_images: dict[int, bytes] = {}
    accepted_horizons: list[int] = []
    rejected_horizons: list[int] = []

    for horizon, return_path in return_paths.items():
        returns = read_returns(return_path, config.time_range)
        result = run_horizon(factor, returns, horizon, config.backtest)
        admission = evaluate_admission(result.metrics, config.admission.rules)
        payload = _horizon_payload(
            config.factor.name,
            result,
            admission,
            config,
            return_path,
            return_path in generated_return_files,
        )
        horizon_payloads[horizon] = payload
        if admission["passed"]:
            accepted_horizons.append(horizon)
        else:
            rejected_horizons.append(horizon)

        horizon_directory = output_root / f"{horizon}min"
        horizon_directory.mkdir(parents=True, exist_ok=True)
        if config.output.save_metrics_json:
            _write_json(horizon_directory / "metrics.json", payload)
        if config.output.save_strategy_parquet:
            _save_strategy(horizon_directory / "strategy.parquet", result)
        if config.output.save_report_png or config.output.save_report_html:
            report_image = render_report_png(
                config.factor.name,
                result,
                admission,
            )
            if config.output.save_report_html:
                report_images[horizon] = report_image
            if config.output.save_report_png:
                (horizon_directory / "report.png").write_bytes(report_image)

    summary = {
        "library_version": __version__,
        "factor": config.factor.name,
        "instrument": config.market.instrument,
        "factor_path": str(config.factor.path),
        "factor_sha256": _sha256(config.factor.path),
        "swap_path": str(config.market.close_path),
        "generated_return_files": [
            str(path) for path in generated_return_files
        ],
        "passed": bool(accepted_horizons),
        "time_range": {
            "start": config.time_range.start.isoformat(),
            "end": config.time_range.end.isoformat(),
            "interval": "[start, end)",
        },
        "accepted_horizons": accepted_horizons,
        "rejected_horizons": rejected_horizons,
        "horizons": {
            f"{horizon}min": {
                "passed": payload["admission"]["passed"],
                **payload["metrics"],
                "rejection_reasons": payload["admission"]["rejection_reasons"],
            }
            for horizon, payload in horizon_payloads.items()
        },
    }
    _write_json(output_root / "summary.json", summary)

    html_report_path = None
    if config.output.save_report_html:
        html_report_path = save_html_report(
            config.factor.name,
            config.market.instrument,
            summary,
            horizon_payloads,
            report_images,
            output_root / "report.html",
        )

    registry_directory = None
    if accepted_horizons:
        registry_directory = _write_registry(config, summary, horizon_payloads)

    return BacktestRunResult(
        summary=_json_safe(summary),
        output_directory=output_root,
        registry_directory=registry_directory,
        generated_return_files=tuple(generated_return_files),
        html_report_path=html_report_path,
    )
