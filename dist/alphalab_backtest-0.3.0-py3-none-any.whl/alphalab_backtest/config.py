from __future__ import annotations

import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd
import yaml


class ConfigError(ValueError):
    """Raised when a backtest YAML file is invalid."""


@dataclass(frozen=True)
class FactorConfig:
    name: str
    path: Path


@dataclass(frozen=True)
class MarketConfig:
    instrument: str
    swap_directory: Path

    @property
    def close_path(self) -> Path:
        return self.swap_directory / f"{self.instrument}.parquet"


@dataclass(frozen=True)
class ReturnsConfig:
    directory: Path
    file_pattern: str

    def path_for(self, instrument: str, horizon: int) -> Path:
        return self.directory / self.file_pattern.format(
            instrument=instrument,
            horizon=horizon,
        )


@dataclass(frozen=True)
class TimeRangeConfig:
    start: pd.Timestamp
    end: pd.Timestamp


@dataclass(frozen=True)
class DirectionConfig:
    window: str
    min_observations: int


@dataclass(frozen=True)
class GroupingConfig:
    quantiles: int
    long_groups: tuple[int, ...]
    short_groups: tuple[int, ...]


@dataclass(frozen=True)
class CostsConfig:
    fee_bps: float
    slippage_bps: float

    @property
    def total_rate(self) -> float:
        return (self.fee_bps + self.slippage_bps) / 10_000


@dataclass(frozen=True)
class BacktestConfig:
    prediction_horizons: tuple[int, ...]
    direction: DirectionConfig
    grouping: GroupingConfig
    costs: CostsConfig


@dataclass(frozen=True)
class AdmissionRules:
    min_valid_samples: int | None
    min_coverage: float | None
    min_ic: float | None
    min_icir: float | None
    min_sharpe: float | None
    max_absolute_drawdown: float | None


@dataclass(frozen=True)
class AdmissionConfig:
    rules: AdmissionRules


@dataclass(frozen=True)
class RegistryConfig:
    directory: Path
    copy_factor_file: bool
    overwrite: bool


@dataclass(frozen=True)
class OutputConfig:
    directory: Path
    save_metrics_json: bool
    save_strategy_parquet: bool
    save_report_png: bool
    save_report_html: bool
    save_config_snapshot: bool


@dataclass(frozen=True)
class Config:
    source_path: Path
    factor: FactorConfig
    market: MarketConfig
    returns: ReturnsConfig
    time_range: TimeRangeConfig
    backtest: BacktestConfig
    admission: AdmissionConfig
    registry: RegistryConfig
    output: OutputConfig


def _mapping(value: Any, label: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ConfigError(f"{label} must be a mapping.")
    return value


def _reject_unknown(mapping: dict[str, Any], allowed: set[str], label: str) -> None:
    unknown = sorted(set(mapping) - allowed)
    if unknown:
        raise ConfigError(f"Unknown {label} key(s): {', '.join(unknown)}")


def _required(mapping: dict[str, Any], key: str, label: str) -> Any:
    if key not in mapping:
        raise ConfigError(f"Missing required key: {label}.{key}")
    return mapping[key]


def _resolve_path(value: Any, base_dir: Path, label: str) -> Path:
    if not isinstance(value, (str, Path)) or not str(value).strip():
        raise ConfigError(f"{label} must be a non-empty path.")
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = base_dir / path
    return path.resolve()


def _positive_int(value: Any, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise ConfigError(f"{label} must be a positive integer.")
    return value


def _non_negative_number(value: Any, label: str) -> float:
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(value)
        or value < 0
    ):
        raise ConfigError(f"{label} must be a non-negative number.")
    return float(value)


def _optional_number(mapping: dict[str, Any], key: str, label: str) -> float | None:
    value = mapping.get(key)
    if value is None:
        return None
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(value)
    ):
        raise ConfigError(f"{label}.{key} must be a number or null.")
    return float(value)


def _boolean(mapping: dict[str, Any], key: str, default: bool, label: str) -> bool:
    value = mapping.get(key, default)
    if not isinstance(value, bool):
        raise ConfigError(f"{label}.{key} must be true or false.")
    return value


def _timestamp(value: Any, label: str) -> pd.Timestamp:
    try:
        timestamp = pd.Timestamp(value)
    except (TypeError, ValueError) as exc:
        raise ConfigError(f"{label} is not a valid timestamp: {value!r}") from exc
    if pd.isna(timestamp):
        raise ConfigError(f"{label} is not a valid timestamp: {value!r}")
    if timestamp.tzinfo is None:
        timestamp = timestamp.tz_localize("UTC")
    else:
        timestamp = timestamp.tz_convert("UTC")
    return timestamp


def load_config(path: str | Path) -> Config:
    source_path = Path(path).expanduser().resolve()
    if not source_path.is_file():
        raise ConfigError(f"Config file not found: {source_path}")

    try:
        with source_path.open("r", encoding="utf-8") as file:
            loaded = yaml.safe_load(file)
    except yaml.YAMLError as exc:
        raise ConfigError(f"Invalid YAML in {source_path}: {exc}") from exc

    root = _mapping(loaded, "config")
    _reject_unknown(
        root,
        {
            "version",
            "factor",
            "market",
            "returns",
            "time_range",
            "backtest",
            "admission",
            "registry",
            "output",
        },
        "config",
    )
    if root.get("version") != 2:
        raise ConfigError("config.version must be 2.")
    base_dir = source_path.parent

    factor_node = _mapping(_required(root, "factor", "config"), "factor")
    _reject_unknown(factor_node, {"name", "path"}, "factor")
    factor_path = _resolve_path(_required(factor_node, "path", "factor"), base_dir, "factor.path")
    factor_name_value = factor_node.get("name", factor_path.stem)
    if not isinstance(factor_name_value, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", factor_name_value):
        raise ConfigError("factor.name must contain only letters, numbers, dot, underscore or hyphen.")
    factor = FactorConfig(name=factor_name_value, path=factor_path)

    market_node = _mapping(_required(root, "market", "config"), "market")
    _reject_unknown(market_node, {"instrument", "swap_directory"}, "market")
    instrument = _required(market_node, "instrument", "market")
    if (
        not isinstance(instrument, str)
        or not re.fullmatch(r"[A-Z0-9]+(?:-[A-Z0-9]+)*-SWAP", instrument)
    ):
        raise ConfigError(
            "market.instrument must be an uppercase perpetual instrument ending in -SWAP, "
            "for example BTC-USDT-SWAP."
        )
    market = MarketConfig(
        instrument=instrument,
        swap_directory=_resolve_path(
            _required(market_node, "swap_directory", "market"),
            base_dir,
            "market.swap_directory",
        ),
    )

    returns_node = _mapping(_required(root, "returns", "config"), "returns")
    _reject_unknown(returns_node, {"directory", "file_pattern"}, "returns")
    returns_directory = _resolve_path(
        _required(returns_node, "directory", "returns"),
        base_dir,
        "returns.directory",
    )
    file_pattern = returns_node.get(
        "file_pattern",
        "{instrument}/{horizon}min.parquet",
    )
    if not isinstance(file_pattern, str) or not file_pattern:
        raise ConfigError("returns.file_pattern must be a non-empty string.")
    try:
        formatted_pattern = file_pattern.format(
            instrument="BTC-USDT-SWAP",
            horizon=1,
        )
    except (KeyError, ValueError) as exc:
        raise ConfigError(
            "returns.file_pattern may only use {instrument} and {horizon} placeholders."
        ) from exc
    if "{horizon}" not in file_pattern or "{instrument}" not in file_pattern:
        raise ConfigError(
            "returns.file_pattern must contain both {instrument} and {horizon} placeholders."
        )
    formatted_path = Path(formatted_pattern)
    if formatted_path.is_absolute() or ".." in formatted_path.parts:
        raise ConfigError("returns.file_pattern must format to a relative path without '..'.")
    returns = ReturnsConfig(directory=returns_directory, file_pattern=file_pattern)

    time_node = _mapping(_required(root, "time_range", "config"), "time_range")
    _reject_unknown(time_node, {"start", "end"}, "time_range")
    start = _timestamp(_required(time_node, "start", "time_range"), "time_range.start")
    end = _timestamp(_required(time_node, "end", "time_range"), "time_range.end")
    if start >= end:
        raise ConfigError("time_range.start must be earlier than time_range.end.")
    time_range = TimeRangeConfig(start=start, end=end)

    backtest_node = _mapping(_required(root, "backtest", "config"), "backtest")
    _reject_unknown(backtest_node, {"prediction_horizons", "direction", "grouping", "costs"}, "backtest")
    horizon_values = _required(backtest_node, "prediction_horizons", "backtest")
    if not isinstance(horizon_values, list) or not horizon_values:
        raise ConfigError("backtest.prediction_horizons must be a non-empty list.")
    horizons = tuple(sorted(_positive_int(value, "backtest.prediction_horizons item") for value in horizon_values))
    if len(set(horizons)) != len(horizons):
        raise ConfigError("backtest.prediction_horizons must not contain duplicates.")

    direction_node = _mapping(_required(backtest_node, "direction", "backtest"), "backtest.direction")
    _reject_unknown(direction_node, {"method", "window", "min_observations"}, "backtest.direction")
    if direction_node.get("method", "rolling_ic") != "rolling_ic":
        raise ConfigError("backtest.direction.method must be rolling_ic.")
    direction_window = direction_node.get("window", "30D")
    if not isinstance(direction_window, str):
        raise ConfigError("backtest.direction.window must be a pandas time-window string.")
    try:
        if pd.Timedelta(direction_window) <= pd.Timedelta(0):
            raise ValueError
    except (TypeError, ValueError) as exc:
        raise ConfigError("backtest.direction.window must be a positive pandas time-window string.") from exc
    min_observations = _positive_int(
        direction_node.get("min_observations", 30 * 24 * 60),
        "backtest.direction.min_observations",
    )
    direction = DirectionConfig(window=direction_window, min_observations=min_observations)

    grouping_node = _mapping(_required(backtest_node, "grouping", "backtest"), "backtest.grouping")
    _reject_unknown(grouping_node, {"quantiles", "long_groups", "short_groups"}, "backtest.grouping")
    quantiles = _positive_int(grouping_node.get("quantiles", 10), "backtest.grouping.quantiles")
    if quantiles < 2:
        raise ConfigError("backtest.grouping.quantiles must be at least 2.")

    def parse_groups(key: str, default: list[int]) -> tuple[int, ...]:
        values = grouping_node.get(key, default)
        if not isinstance(values, list) or not values:
            raise ConfigError(f"backtest.grouping.{key} must be a non-empty list.")
        groups = tuple(sorted(_positive_int(value, f"backtest.grouping.{key} item") for value in values))
        if len(set(groups)) != len(groups):
            raise ConfigError(f"backtest.grouping.{key} must not contain duplicates.")
        if groups[-1] > quantiles:
            raise ConfigError(f"backtest.grouping.{key} values must be between 1 and {quantiles}.")
        return groups

    long_groups = parse_groups("long_groups", [quantiles])
    short_groups = parse_groups("short_groups", [1])
    if set(long_groups) & set(short_groups):
        raise ConfigError("backtest.grouping.long_groups and short_groups must not overlap.")
    grouping = GroupingConfig(
        quantiles=quantiles,
        long_groups=long_groups,
        short_groups=short_groups,
    )

    costs_node = _mapping(backtest_node.get("costs", {}), "backtest.costs")
    _reject_unknown(costs_node, {"fee_bps", "slippage_bps"}, "backtest.costs")
    costs = CostsConfig(
        fee_bps=_non_negative_number(costs_node.get("fee_bps", 0), "backtest.costs.fee_bps"),
        slippage_bps=_non_negative_number(
            costs_node.get("slippage_bps", 0),
            "backtest.costs.slippage_bps",
        ),
    )
    backtest = BacktestConfig(
        prediction_horizons=horizons,
        direction=direction,
        grouping=grouping,
        costs=costs,
    )

    admission_node = _mapping(root.get("admission", {}), "admission")
    _reject_unknown(admission_node, {"mode", "rules"}, "admission")
    if admission_node.get("mode", "per_horizon") != "per_horizon":
        raise ConfigError("admission.mode must be per_horizon.")
    rules_node = _mapping(admission_node.get("rules", {}), "admission.rules")
    _reject_unknown(
        rules_node,
        {
            "min_valid_samples",
            "min_coverage",
            "min_ic",
            "min_icir",
            "min_sharpe",
            "max_absolute_drawdown",
        },
        "admission.rules",
    )
    min_valid_samples_value = rules_node.get("min_valid_samples")
    min_valid_samples = (
        None
        if min_valid_samples_value is None
        else _positive_int(min_valid_samples_value, "admission.rules.min_valid_samples")
    )
    min_coverage = _optional_number(rules_node, "min_coverage", "admission.rules")
    if min_coverage is not None and not 0 <= min_coverage <= 1:
        raise ConfigError("admission.rules.min_coverage must be between 0 and 1.")
    max_absolute_drawdown = _optional_number(
        rules_node,
        "max_absolute_drawdown",
        "admission.rules",
    )
    if max_absolute_drawdown is not None and max_absolute_drawdown < 0:
        raise ConfigError("admission.rules.max_absolute_drawdown must be non-negative.")
    admission = AdmissionConfig(
        rules=AdmissionRules(
            min_valid_samples=min_valid_samples,
            min_coverage=min_coverage,
            min_ic=_optional_number(rules_node, "min_ic", "admission.rules"),
            min_icir=_optional_number(rules_node, "min_icir", "admission.rules"),
            min_sharpe=_optional_number(rules_node, "min_sharpe", "admission.rules"),
            max_absolute_drawdown=max_absolute_drawdown,
        )
    )

    registry_node = _mapping(_required(root, "registry", "config"), "registry")
    _reject_unknown(registry_node, {"directory", "copy_factor_file", "overwrite"}, "registry")
    registry = RegistryConfig(
        directory=_resolve_path(
            _required(registry_node, "directory", "registry"),
            base_dir,
            "registry.directory",
        ),
        copy_factor_file=_boolean(registry_node, "copy_factor_file", True, "registry"),
        overwrite=_boolean(registry_node, "overwrite", False, "registry"),
    )

    output_node = _mapping(_required(root, "output", "config"), "output")
    _reject_unknown(
        output_node,
        {
            "directory",
            "save_metrics_json",
            "save_strategy_parquet",
            "save_report_png",
            "save_report_html",
            "save_config_snapshot",
        },
        "output",
    )
    output = OutputConfig(
        directory=_resolve_path(
            _required(output_node, "directory", "output"),
            base_dir,
            "output.directory",
        ),
        save_metrics_json=_boolean(output_node, "save_metrics_json", True, "output"),
        save_strategy_parquet=_boolean(output_node, "save_strategy_parquet", True, "output"),
        save_report_png=_boolean(output_node, "save_report_png", True, "output"),
        save_report_html=_boolean(output_node, "save_report_html", True, "output"),
        save_config_snapshot=_boolean(output_node, "save_config_snapshot", True, "output"),
    )

    registry_target = registry.directory / market.instrument / factor.name
    output_target = output.directory / market.instrument / factor.name
    if registry_target == output_target:
        raise ConfigError("registry and output factor directories must be different.")
    if registry_target.is_relative_to(output_target) or output_target.is_relative_to(registry_target):
        raise ConfigError("registry and output factor directories must not contain one another.")
    if factor.path.is_relative_to(registry_target):
        raise ConfigError("factor.path must not be inside its target registry directory.")
    if source_path.is_relative_to(registry_target):
        raise ConfigError("The YAML config file must not be inside its target registry directory.")

    return Config(
        source_path=source_path,
        factor=factor,
        market=market,
        returns=returns,
        time_range=time_range,
        backtest=backtest,
        admission=admission,
        registry=registry,
        output=output,
    )
