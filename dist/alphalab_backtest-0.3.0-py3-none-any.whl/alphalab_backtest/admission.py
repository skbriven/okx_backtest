from __future__ import annotations

import math
from dataclasses import asdict
from typing import Any

from .config import AdmissionRules


def _finite(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def evaluate_admission(
    metrics: dict[str, float | int],
    rules: AdmissionRules,
) -> dict[str, Any]:
    checks: dict[str, dict[str, Any]] = {}
    configured_rules = asdict(rules)

    for rule_name, required in configured_rules.items():
        if required is None:
            continue

        if rule_name == "max_absolute_drawdown":
            metric_name = "max_drawdown"
            raw_actual = metrics.get(metric_name)
            actual = abs(raw_actual) if _finite(raw_actual) else None
            passed = actual is not None and actual <= required
        else:
            metric_name = rule_name.removeprefix("min_")
            if rule_name == "min_valid_samples":
                metric_name = "valid_samples"
            raw_actual = metrics.get(metric_name)
            actual = raw_actual if _finite(raw_actual) else None
            passed = actual is not None and actual >= required

        checks[rule_name] = {
            "metric": metric_name,
            "required": required,
            "actual": actual,
            "passed": bool(passed),
        }

    rejection_reasons = [
        f"{name}: required {check['required']}, actual {check['actual']}"
        for name, check in checks.items()
        if not check["passed"]
    ]
    return {
        "passed": all(check["passed"] for check in checks.values()),
        "checks": checks,
        "rejection_reasons": rejection_reasons,
    }
