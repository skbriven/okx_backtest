from __future__ import annotations

import base64
import html
import math
from pathlib import Path
from typing import Any


def _escape(value: Any) -> str:
    return html.escape(str(value))


def _finite(value: Any) -> bool:
    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(value)
    )


def _number(value: Any, decimals: int = 4) -> str:
    if not _finite(value):
        return "nan"
    if abs(value) >= 1_000_000:
        return f"{value:.3e}"
    return f"{value:.{decimals}f}"


def _percent(value: Any) -> str:
    if not _finite(value):
        return "nan"
    percentage = value * 100
    if abs(percentage) >= 1_000_000:
        return f"{percentage:.3e}%"
    return f"{percentage:.2f}%"


def _integer(value: Any) -> str:
    if not _finite(value):
        return "nan"
    return f"{int(value):,}"


def _metric_cards(metrics: dict[str, Any]) -> str:
    definitions = [
        ("IC", _number(metrics.get("ic"))),
        ("ICIR", _number(metrics.get("icir"))),
        ("Annual return", _percent(metrics.get("annual_return"))),
        ("Sharpe", _number(metrics.get("sharpe"))),
        ("Max drawdown", _percent(metrics.get("max_drawdown"))),
        ("Calmar", _number(metrics.get("calmar"))),
        ("Final NAV", _number(metrics.get("final_nav"), 2)),
        ("Coverage", _percent(metrics.get("coverage"))),
        ("Valid samples", _integer(metrics.get("valid_samples"))),
        ("Open frequency", _percent(metrics.get("open_frequency"))),
    ]
    return "".join(
        (
            '<div class="metric-card">'
            f'<div class="metric-label">{_escape(label)}</div>'
            f'<div class="metric-value">{_escape(value)}</div>'
            "</div>"
        )
        for label, value in definitions
    )


def _admission_table(admission: dict[str, Any]) -> str:
    checks = admission.get("checks", {})
    if not checks:
        return '<p class="empty-state">No admission rules configured.</p>'

    rows = []
    for name, check in checks.items():
        passed = bool(check.get("passed"))
        rows.append(
            "<tr>"
            f"<td>{_escape(name)}</td>"
            f"<td>{_escape(check.get('metric', ''))}</td>"
            f"<td>{_escape(_number(check.get('required')))}</td>"
            f"<td>{_escape(_number(check.get('actual')))}</td>"
            f'<td><span class="badge {"pass" if passed else "reject"}">'
            f'{"PASS" if passed else "REJECT"}</span></td>'
            "</tr>"
        )
    return (
        '<div class="table-wrap"><table>'
        "<thead><tr><th>Rule</th><th>Metric</th><th>Required</th>"
        "<th>Actual</th><th>Status</th></tr></thead>"
        f"<tbody>{''.join(rows)}</tbody></table></div>"
    )


def _group_table(group_returns: dict[str, Any]) -> str:
    rows = []
    for group, value in group_returns.items():
        basis_points = value * 10_000 if _finite(value) else None
        rows.append(
            "<tr>"
            f"<td>{_escape(group)}</td>"
            f"<td>{_escape(_number(basis_points, 3))}</td>"
            "</tr>"
        )
    return (
        '<div class="table-wrap compact"><table>'
        "<thead><tr><th>Group</th><th>Mean forward return (bp)</th></tr></thead>"
        f"<tbody>{''.join(rows)}</tbody></table></div>"
    )


def _horizon_section(
    horizon: int,
    payload: dict[str, Any],
    image: bytes,
    selected: bool,
) -> str:
    admission = payload["admission"]
    passed = bool(admission["passed"])
    image_base64 = base64.b64encode(image).decode("ascii")
    generated = bool(payload.get("return_file_generated"))
    reasons = admission.get("rejection_reasons", [])
    reason_html = ""
    if reasons:
        reason_html = (
            '<div class="rejection-box"><strong>Rejection reasons</strong><ul>'
            + "".join(f"<li>{_escape(reason)}</li>" for reason in reasons)
            + "</ul></div>"
        )

    return f"""
    <section class="horizon-panel{" active" if selected else ""}" data-horizon="{horizon}">
      <div class="panel-heading">
        <div>
          <p class="eyebrow">Prediction horizon</p>
          <h2>{horizon} minutes</h2>
        </div>
        <span class="badge {"pass" if passed else "reject"}">{"PASS" if passed else "REJECT"}</span>
      </div>

      <div class="source-line">
        <span>Return file: <code>{_escape(payload.get("return_path", ""))}</code></span>
        <span class="badge {"generated" if generated else "existing"}">
          {"GENERATED" if generated else "EXISTING"}
        </span>
      </div>

      <div class="metric-grid">{_metric_cards(payload["metrics"])}</div>
      {reason_html}

      <div class="two-column">
        <article class="card">
          <h3>Admission checks</h3>
          {_admission_table(admission)}
        </article>
        <article class="card">
          <h3>Group returns</h3>
          {_group_table(payload["group_mean_forward_returns"])}
        </article>
      </div>

      <article class="card chart-card">
        <h3>Backtest charts</h3>
        <img
          src="data:image/png;base64,{image_base64}"
          alt="{horizon} minute backtest charts"
        >
      </article>
    </section>
    """


def save_html_report(
    factor_name: str,
    instrument: str,
    summary: dict[str, Any],
    horizon_payloads: dict[int, dict[str, Any]],
    report_images: dict[int, bytes],
    output_path: Path,
) -> Path:
    horizons = sorted(horizon_payloads)
    if not horizons:
        raise ValueError("Cannot create an HTML report without horizon results.")

    options = "".join(
        f'<option value="{horizon}">{horizon} minutes</option>'
        for horizon in horizons
    )
    sections = "".join(
        _horizon_section(
            horizon,
            horizon_payloads[horizon],
            report_images[horizon],
            selected=index == 0,
        )
        for index, horizon in enumerate(horizons)
    )
    accepted = ", ".join(f"{value}min" for value in summary["accepted_horizons"]) or "None"
    rejected = ", ".join(f"{value}min" for value in summary["rejected_horizons"]) or "None"
    time_range = summary["time_range"]

    document = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{_escape(factor_name)} backtest report</title>
  <style>
    :root {{
      color-scheme: light;
      --bg: #f4f7fb;
      --surface: #ffffff;
      --surface-soft: #f8fafc;
      --text: #172033;
      --muted: #64748b;
      --border: #dbe3ef;
      --accent: #2563eb;
      --pass: #15803d;
      --pass-bg: #dcfce7;
      --reject: #b91c1c;
      --reject-bg: #fee2e2;
      --generated: #7c3aed;
      --generated-bg: #ede9fe;
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    }}
    * {{ box-sizing: border-box; }}
    body {{ margin: 0; background: var(--bg); color: var(--text); }}
    main {{ width: min(1500px, calc(100% - 32px)); margin: 28px auto 48px; }}
    .hero {{
      padding: 28px 32px;
      border-radius: 20px;
      color: white;
      background: linear-gradient(135deg, #172554, #1d4ed8 58%, #0f766e);
      box-shadow: 0 18px 50px rgba(30, 64, 175, .18);
    }}
    .hero h1 {{ margin: 6px 0 10px; font-size: clamp(28px, 4vw, 46px); }}
    .hero p {{ margin: 4px 0; color: #dbeafe; }}
    .hero-grid {{ display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 12px; margin-top: 24px; }}
    .hero-stat {{ padding: 14px 16px; border: 1px solid rgba(255,255,255,.22); border-radius: 13px; background: rgba(255,255,255,.09); }}
    .hero-stat span {{ display: block; font-size: 12px; color: #bfdbfe; text-transform: uppercase; letter-spacing: .07em; }}
    .hero-stat strong {{ display: block; margin-top: 6px; font-size: 16px; word-break: break-word; }}
    .toolbar {{ display: flex; align-items: center; gap: 14px; margin: 22px 0; padding: 16px 18px; border: 1px solid var(--border); border-radius: 14px; background: var(--surface); }}
    .toolbar label {{ font-weight: 700; }}
    select {{ min-width: 210px; padding: 10px 38px 10px 12px; border: 1px solid #aebbd0; border-radius: 9px; background: white; color: var(--text); font-size: 15px; }}
    .horizon-panel {{ display: none; }}
    .horizon-panel.active {{ display: block; }}
    .panel-heading {{ display: flex; justify-content: space-between; align-items: center; gap: 16px; margin: 24px 2px 14px; }}
    .panel-heading h2 {{ margin: 2px 0 0; font-size: 30px; }}
    .eyebrow {{ margin: 0; color: var(--muted); font-size: 12px; font-weight: 800; letter-spacing: .11em; text-transform: uppercase; }}
    .badge {{ display: inline-flex; align-items: center; width: fit-content; padding: 5px 10px; border-radius: 999px; font-size: 12px; font-weight: 800; letter-spacing: .04em; }}
    .badge.pass {{ color: var(--pass); background: var(--pass-bg); }}
    .badge.reject {{ color: var(--reject); background: var(--reject-bg); }}
    .badge.generated {{ color: var(--generated); background: var(--generated-bg); }}
    .badge.existing {{ color: #475569; background: #e2e8f0; }}
    .source-line {{ display: flex; justify-content: space-between; align-items: center; gap: 12px; padding: 12px 15px; border: 1px solid var(--border); border-radius: 11px; background: var(--surface-soft); color: var(--muted); }}
    code {{ overflow-wrap: anywhere; color: #334155; }}
    .metric-grid {{ display: grid; grid-template-columns: repeat(5, minmax(0, 1fr)); gap: 12px; margin: 16px 0; }}
    .metric-card, .card {{ border: 1px solid var(--border); border-radius: 14px; background: var(--surface); box-shadow: 0 7px 22px rgba(15, 23, 42, .04); }}
    .metric-card {{ padding: 15px 16px; }}
    .metric-label {{ color: var(--muted); font-size: 12px; font-weight: 700; }}
    .metric-value {{ margin-top: 7px; overflow-wrap: anywhere; font-size: clamp(17px, 1.55vw, 22px); font-weight: 800; }}
    .two-column {{ display: grid; grid-template-columns: 1.4fr 1fr; gap: 16px; margin: 16px 0; }}
    .card {{ padding: 18px; }}
    .card h3 {{ margin: 0 0 14px; }}
    .chart-card img {{ display: block; width: 100%; height: auto; border-radius: 9px; }}
    .table-wrap {{ overflow-x: auto; }}
    table {{ width: 100%; border-collapse: collapse; font-size: 13px; }}
    th, td {{ padding: 9px 10px; border-bottom: 1px solid var(--border); text-align: left; }}
    th {{ color: var(--muted); background: var(--surface-soft); font-size: 11px; text-transform: uppercase; letter-spacing: .05em; }}
    .compact {{ max-height: 315px; overflow-y: auto; }}
    .rejection-box {{ margin: 14px 0; padding: 14px 17px; border: 1px solid #fecaca; border-radius: 12px; color: #991b1b; background: #fff1f2; }}
    .rejection-box ul {{ margin-bottom: 0; }}
    .empty-state {{ color: var(--muted); }}
    @media (max-width: 950px) {{
      .hero-grid, .metric-grid {{ grid-template-columns: repeat(2, minmax(0, 1fr)); }}
      .two-column {{ grid-template-columns: 1fr; }}
    }}
    @media (max-width: 560px) {{
      main {{ width: min(100% - 18px, 1500px); margin-top: 9px; }}
      .hero {{ padding: 22px 20px; border-radius: 14px; }}
      .hero-grid, .metric-grid {{ grid-template-columns: 1fr; }}
      .toolbar, .source-line {{ align-items: stretch; flex-direction: column; }}
      select {{ width: 100%; }}
    }}
  </style>
</head>
<body>
  <main>
    <header class="hero">
      <p class="eyebrow">AlphaLab factor report</p>
      <h1>{_escape(factor_name)}</h1>
      <p>{_escape(instrument)} · Full-period backtest</p>
      <div class="hero-grid">
        <div class="hero-stat"><span>Period</span><strong>{_escape(time_range["start"])}<br>{_escape(time_range["end"])}</strong></div>
        <div class="hero-stat"><span>Accepted</span><strong>{_escape(accepted)}</strong></div>
        <div class="hero-stat"><span>Rejected</span><strong>{_escape(rejected)}</strong></div>
        <div class="hero-stat"><span>Library</span><strong>{_escape(summary["library_version"])}</strong></div>
      </div>
    </header>

    <div class="toolbar">
      <label for="horizon-select">Prediction horizon</label>
      <select id="horizon-select">{options}</select>
      <span class="empty-state">Choose a horizon to switch all metrics and charts.</span>
    </div>

    {sections}
  </main>
  <script>
    const select = document.getElementById("horizon-select");
    const panels = Array.from(document.querySelectorAll(".horizon-panel"));
    function showHorizon(value) {{
      panels.forEach(panel => {{
        panel.classList.toggle("active", panel.dataset.horizon === value);
      }});
    }}
    select.addEventListener("change", event => showHorizon(event.target.value));
    showHorizon(select.value);
  </script>
</body>
</html>
"""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(document, encoding="utf-8")
    return output_path
