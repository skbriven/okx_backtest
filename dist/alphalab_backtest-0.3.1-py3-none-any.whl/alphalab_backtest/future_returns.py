from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from pandas.api.types import is_numeric_dtype

from .data import DataValidationError, _timestamp_index


def read_close(path: Path) -> pd.Series:
    if not path.is_file():
        raise FileNotFoundError(f"Swap parquet not found: {path}")
    frame = pd.read_parquet(path)

    timestamp_column = next(
        (column for column in ("timestamp", "datetime_utc") if column in frame.columns),
        None,
    )
    if timestamp_column is not None:
        if "close" not in frame.columns:
            raise DataValidationError(
                f"Swap parquet with a {timestamp_column} column must also contain close: {path}"
            )
        frame = frame[[timestamp_column, "close"]].set_index(timestamp_column)
    elif "close" in frame.columns:
        frame = frame[["close"]]
    else:
        raise DataValidationError(f"Swap parquet must contain a close column: {path}")

    if not is_numeric_dtype(frame["close"]):
        raise DataValidationError(f"Swap close column must be numeric: {path}")
    frame.index = _timestamp_index(frame.index, path)
    frame = frame.sort_index()

    valid_close = frame["close"].dropna()
    if valid_close.empty:
        raise DataValidationError(f"Swap close column contains no valid values: {path}")
    if not np.isfinite(valid_close).all():
        raise DataValidationError(f"Swap close values must be finite: {path}")
    if (valid_close <= 0).any():
        raise DataValidationError(f"Swap close values must be positive: {path}")
    return frame["close"]


def calculate_future_returns(close: pd.Series, horizon_minutes: int) -> pd.DataFrame:
    timestamp = close.index
    entry_values = close.reindex(
        timestamp + pd.Timedelta(minutes=1)
    ).to_numpy()
    exit_values = close.reindex(
        timestamp + pd.Timedelta(minutes=horizon_minutes + 1)
    ).to_numpy()
    with np.errstate(divide="ignore", invalid="ignore"):
        values = exit_values / entry_values - 1
    return pd.DataFrame(
        {"return": values},
        index=pd.DatetimeIndex(timestamp, name="timestamp"),
    )


def write_future_returns(
    close: pd.Series,
    horizon_minutes: int,
    output_path: Path,
) -> Path:
    future_returns = calculate_future_returns(close, horizon_minutes)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = output_path.with_name(f".{output_path.name}.tmp")
    future_returns.to_parquet(temporary_path, index=True)
    temporary_path.replace(output_path)
    return output_path
